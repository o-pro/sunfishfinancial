<?php

session_start();

if (isset($_SESSION['id']) && isset($_SESSION['user_name'])) {

 ?>


<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>SunFish Financial</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout">
      <!-- loader  -->
      <div class="loader_bg">
         <div class="loader"><img src="images/loading.gif" alt="#" /></div>
      </div>
      <!-- end loader -->
      <!-- header -->
      <header>
         <!-- header inner -->
         <div class="header">
            <div class="white_bg">
               <div class="container-fluid">
                  <div class="row">
                     <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col logo_section">
                        <div class="full">
                           <div class="center-desk">
                              <div class="logo">
                                 <a href="index.html"><img src="images/sunfishlogo.svg" alt="#" /></a>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9">
                        <nav class="navigation navbar navbar-expand-md navbar-dark ">
                           <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample04" aria-controls="navbarsExample04" aria-expanded="false" aria-label="Toggle navigation">
                           <span class="navbar-toggler-icon"></span>
                           </button>
                           <div class="collapse navbar-collapse" id="navbarsExample04">
                              <ul class="navbar-nav mr-auto">
                                 <li class="nav-item">
                                    <a class="nav-link" href="logout.php"> Logout  </a>
                                 </li>
                              </ul>
                           </div>
                        </nav>
                     </div>
                  </div>
               </div>
               <!-- end header inner -->
               <!-- end header -->
               <!-- banner -->
               <!-- 00461f -->
               <!-- fbca47 -->
               <section class="banner_main">
                  <div id="banner1" class="carousel slide" data-ride="carousel">
                     <div class="carousel-inner">
                        <div class="carousel-item active">
                           <div class="container-fluid">
                              <div class="carousel-caption">
                                 <div class="row">
                                    <div class="col-lg-12" >
                                       <div class="text-bg">
                                         <form style="border-style: outset; border-color: #fbca47; width:512px; display: block; margin: 0 auto; padding-top: 72px;" class="contac_form" action="home.php" method="get">
                                           <h2 style="text-align: center; color: #00461f;"><u>Lookup Transactions</u></h2>
                                           <input type="hidden" name="table" value="accounts">
                                           <input type="hidden" name="field" value="account_num">
                                           <input class="contac_control" style="width:384px; display: block; margin: 0 auto; margin-bottom: 12px;" type="text" name="value" value="0123456">
                                           <button class="send_btn" style="min-width:384px; margin-top: 0px; margin-bottom:72px;" type="submit">Submit</button>
                                         </form><br>
                                         <?php
                                         $servername = "localhost";
                                         $username = "root";
                                         $password = "deathlyhollows";
                                         $database = 'financial';

                                         // Create connection
                                         $mysqli = new mysqli($servername, $username, $password, $database);

                                         // Check connection
                                         if ($mysqli->connect_error) {
                                           die("Connection failed: " . $mysqli->connect_error);
                                         }

                                         $value = $_GET["value"];
                                         $table = $_GET["table"];
                                         $field = $_GET["field"];

                                         if (!is_null($value) and !is_null($table) and !is_null($field)){
                                           $sql = "SELECT * FROM $table WHERE $field LIKE $value;";
                                           // $colquery = "SHOW COLUMNS FROM $table;";
                                           $colquery = "SELECT group_concat(COLUMN_NAME) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = 'financial' AND TABLE_NAME = '$table';";
                                           $colsql = $mysqli->query($colquery);
                                           $col = $colsql->fetch_array(MYSQLI_NUM);
                                           echo '<p style="text-align: center;">' . implode(" ",$col) . "</p>";
                                           // echo '<tr>';
                                           // echo '<td>' . implode(" ",$col) . "</td>";
                                           // echo '</tr>';

                                           if ($mysqli -> multi_query($sql)) {
                                             do {
                                               // Store first result set
                                               if ($result = $mysqli -> store_result()) {
                                                 while ($row = $result -> fetch_row()) {
                                                   echo '<p style="text-align: center;">' . implode(" ",$row) . "</p>";
                                                 }
                                                $result -> free_result();
                                               }
                                               // if there are more result-sets, the print a divider
                                               if ($mysqli -> more_results()) {
                                                 printf("-------------\n");
                                               }
                                                //Prepare next result set
                                             } while ($mysqli -> next_result());
                                           }
                                         }

                                         // $result = $conn->query($sql);
                                         // if ($result->num_rows > 0) {
                                         //   // output data of each row
                                         //   while($row = $result->fetch_assoc()) {
                                         //     echo implode(" ",$row);
                                         //   }
                                         // } else {
                                         //   echo "0 results";
                                         // }
                                         $mysqli->close();
                                         ?>
                                         <!-- <form style="border-style: outset; border-color: #fbca47; width:512px; display: block; margin: 0 auto; padding-top: 72px;" class="contac_form" action="login.php" method="post">
                                           <h1 style="text-align: center; color: #00461f;"><u>Login</u></h1>
                                           <input class="contac_control" style="width:384px; display: block; margin: 0 auto; margin-bottom: 8px;" type="text" name="username" value="Username">
                                           <input class="contac_control" style="width:384px; display: block; margin: 0 auto; margin-bottom: 12px;" type="text" name="password" value="Password">
                                           <button class="send_btn" style="min-width:384px; margin-top: 0px; margin-bottom:72px;" type="submit">Login</button>
                                         </form> -->
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
            </div>
         </div>
      </header>




<footer >
   <div class="footer" style="margin-top: 0px;">
      <div class="container">
         <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6">
               <a class="logo2" href="index.html"><img src="images/sunfishlogo_white.svg" style="height:48px; width:auto;" alt="#"/></a>
               <div class="follow">
                  <p>SunFish financial is not an FCC approved organization and none of our financial instruments are backed by FDIC Insurance - Contact us today to find out more</p>
               </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
               <h3>Quick link</h3>
               <ul class="link_icon">
                  <li> <a href="#"> <i class="fa fa-chevron-right" aria-hidden="index.html"></i>Home</a></li>
                  <li> <a href="#about"> <i class="fa fa-chevron-right" aria-hidden="blog"></i>About </a></li>
                  <li> <a href="#services"> <i class="fa fa-chevron-right" aria-hidden="contact"></i>Services</a></li>
                  <li> <a href="#subscribe"> <i class="fa fa-chevron-right" aria-hidden="blog"></i>Subscribe</a></li>
                  <li> <a href="#contact"> <i class="fa fa-chevron-right" aria-hidden="contact"></i>Contact</a></li>
               </ul>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
               <h3>Social </h3>
               <div class="follow">
                  <p>Follow us to stay connected </p>
                  <ul class="social_icon">
                     <li> <a href="#"><i class="fa fa-facebook-f"></i></a></li>
                     <li> <a href="#"><i class="fa fa-twitter"></i></a></li>
                     <li> <a href="#">   <i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                     <li> <a href="#"><i class="fa fa-instagram"></i></a></li>
                  </ul>
               </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6">
               <h3>Contact us</h3>
               <ul class="location_icon">
                  <li><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i></a>333 Metalback Alley<br>
                     New York, NY 11101
                  </li>
                  <li><a href="#"><i class="fa fa-envelope" aria-hidden="true"></i></a>cents@holey.net</li>
                  <li><a href="#"><i class="fa fa-volume-control-phone" aria-hidden="true"></i></a>+01 (914) 333-3333</li>
               </ul>
            </div>
         </div>
      </div>
      <div class="copyright">
         <div class="container">
            <div class="row">
               <div class="col-md-10 offset-md-1">
                  <p>Copyright 2023 All Rights Reserved</p>
               </div>
            </div>
         </div>
      </div>
   </div>
</footer>
<!-- end footer -->
<!-- Javascript files-->
<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/jquery-3.0.0.min.js"></script>
<!-- sidebar -->
<script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>


<?php

}else{

     header("Location: index.html");

     exit();

}

 ?>

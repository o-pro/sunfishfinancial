<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "deathlyhollows";
$database = 'financial';

// Create connection
$mysqli = new mysqli($servername, $username, $password, $database);

// Check connection
if ($mysqli->connect_error) {
  die("Connection failed: " . $mysqli->connect_error);
}

$username = $_POST["username"];
$password = $_POST["password"];

$sql = "SELECT * FROM users WHERE user_name='$username' AND password='$password';";

$result = $mysqli->query($sql);
if ($result->num_rows > 0) {
  $row = $result->fetch_assoc();
   $_SESSION['user_name'] = $row['user_name'];
   $_SESSION['id'] = $row['user_id'];
   header("Location: home.php");
}
else {
  header("Location: error.html");
}

$mysqli->close();
?>
